/*
Stephan Rhodes
srhodes17@georgefox.edu

David Punzel
dpunzel15@georgefox.edu
*/
function planeChoice(plane){

  for(var index = 0; index < dom.planeButton.length; index++){
    if(dom.planeButton[index].checked)
    {
      plane = dom.planeButton[index].value;
      break;
    }
  }

  switch(plane){
    case 152:
      alert("This is red");
      break;
    case 172:
      alert("This is blue");
      break;
    case 182:
      alert("This is green");
    case 210:
      alert("This is yellow");
    default:
      alert("Error in javascript");
      break;
  }
}
