// JavaScript Document

document.addEventListener("DOMContentLoaded", function() {
    "use strict";


    document.getElementById("submit").addEventListener('submit', validateForm);
});

    /* validate email function */
    function validateEmail(event) {
        "use strict";
        var validInput = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,10})+$/;

        if (event.value.match(validInput)) {
            document.getElementById("email").style.backgroundColor = "white";
            return true;
        }
        else {
            //var invalid = document.getElementById("email");
                document.getElementById("email").style.backgroundColor = "red";
            return false;
        }
    } // end validate email function

    /* validate password function */
    function validatePassword() {
        "use strict";
        var password1 = document.getElementById("password1").value;
        var password2 = document.getElementById("password2").value;

        if (password1 != "") {
            // run pattern check

            var doesPass = checkPassword(password1);
            var doesPass2 = checkPassword(password2);
            if (doesPass === true && doesPass2 === true) {
                // validate match
				if (password1 == password2) {
					document.getElementById("password1").style.backgroundColor = "white";
                    document.getElementById("password2").style.backgroundColor = "white";
                    return true;
				}
                else {
                // prompt user & change background
				if (password1 != password2 || password2 != "") {
					document.getElementById("password1").style.backgroundColor = "red";
                    document.getElementById("password2").style.backgroundColor = "red";
                    document.getElementById("password1").value = "";
                    document.getElementById("password2").value = "";
                    return false;
				}

            } // else password does not match
                // regex doesn't pass
                document.getElementById("password1").style.backgroundColor = "red";
                document.getElementById("password2").style.backgroundColor = "red";
        } // Passes regex validation
            document.getElementById("password1").style.backgroundColor = "red";
            document.getElementById("password2").style.backgroundColor = "red";
    } else {
        document.getElementById("password1").style.backgroundColor = "red";
        document.getElementById("password2").style.backgroundColor = "red";
        return false;
    } // else if password inputs empty
	} // ValidatePassword end

    function validateForm(isValid) {
        "use strict";
        var allIsValid = false;

        // if submit clicked check validatePassword check validateEmail
        if (!allIsValid) {

            var emailField = document.getElementById("email");
            var email = validateEmail(emailField);
            var password = validatePassword();
            var checkBoxesChecked = validateCheckBox();

            /*  CHECK ALL FIELD ON SUBMIT IF TRUE*/
            if (email && password && checkBoxesChecked) {

                allIsValid = true; // all checks passed on submit

            } else {

                // One or more values did not pass
                allIsValid = false;
            }
        }
        return allIsValid;
    } // end of validateForm funcion

      function checkPassword(str) {
        // at least one number, one lowercase and one uppercase letter
        // at least six characters
          "use strict";
        var re = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{6,}$/;
        return re.test(str);
      }

    function validateCheckBox() {
        "use strict";
        var chkbox = document.querySelectorAll('input[type="checkbox"]');
        var checkedOne = Array.prototype.slice.call(chkbox).some(x => x.checked);
        return checkedOne;
    }

    function resetValidationStatus() {
        document.getElementById("signup_form").reset();
        document.getElementById("password1").style.backgroundColor = "white";
        document.getElementById("password2").style.backgroundColor = "white";
        document.getElementById("email").style.backgroundColor = "white";
    }
