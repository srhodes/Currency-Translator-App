<?php


function permute($str,$i,$n) {
    $myArray = array();
   if ($i == $n) {
        $myArray[] = $str;
       //print "$str\n";
   }
   else {
        for ($j = $i; $j < $n; $j++) {
          swap($str,$i,$j);
          permute($str, $i+1, $n);
          swap($str,$i,$j); // backtrack.

        /*  $myArray[j]=$str;
          $myArray=array_unique($myArray);
          print_r($myArray);*/
       }
   }

   $newArray = array();
   $newArray = array_unique($myArray); // not working right now
   print_r($newArray);
   print_r("\n");

}

// function to swap the char at pos $i and $j of $str.
function swap(&$str,$i,$j) {
    $temp = $str[$i];
    $str[$i] = $str[$j];
    $str[$j] = $temp;
}

$str = "olop";
permute($str,0,strlen($str));

?>
<form action="/permutation.php" method="POST">
  <input type="text" name="word" maxlength="8" required>
  <input type="submit">
</form>
