//
//
//
  function chkPasswords(){
    var init = document.getElementById("password1").value;
    var sec = document.getElementById("password2").value;

    if(init.value == "")
    {
      alert("You did not enter a password \n" +
            "Please enter one now");
      return false;
    }

    if(init.value != sec.value){
      alert("The two passwords you entered are not the same \n" +
            "Please re-enter both now");
      return false;
    } else {
      return true;
    }
  }

/*  document.getElementById("password2").onblur = chkPasswords;
  document.getElementById("signup_form").onblur = chkPasswords;*/


  function validateEmail(email){
    var myEmail = document.getElementById("email");
    var emailWord = myEmail.value.search(/^[a-z]@[a-z].[a-z]$/);
    if(emailWord == email)
    {
      alert();
      console.log("Valid email");
      return emailWord;
    }
    else {
      console.log("Invalid email");
    }
  }

//  document.getElementById("email").onchange = validateEmail;
/*
  function continueOrNot(){
    if(validateEmail(document.getElementByName('email').value)){
      alert('valid');
      return true;
    }
    else{
      alert("Invalid")
      return false;
    }
    */
