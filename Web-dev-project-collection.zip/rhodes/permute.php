<?php
$str = htmlspecialchars(strip_tags($_POST["word"]));
function permutation($str) {
    /* If we only have a single character, return it */
    if (strlen($str) < 2) {
        return array($str);
    }

    /* Initialize the return value */
    $permutations = array();

    /* Copy the string except for the first character */
    $tail = substr($str, 1);

    /* Loop through the permutations of the substring created above */
    foreach (permutation($tail) as $permutation) {
        /* Get the length of the current permutation */
        $length = strlen($permutation);

        /* Loop through the permutation and insert the first character of the original
        string between the two parts and store it in the result array */
        for ($i = 0; $i <= $length; $i++) {
            $permutations[] = substr($permutation, 0, $i) . $str[0] . substr($permutation, $i);
        }
    }
    /* Sort Array of permutations */
    sort($permutations);
    /* Return the result */
    return $permutations;
}

$permutations = array_unique(permutation($str));
foreach($permutations as $value) {
    echo $value . "<br>";
}
echo("<a href='/lab6.php'>CLICK ME TO GO BACK</a>");
?>
