// JavaScript Document
/*
Stephan Rhodes
srhodes17@georgefox.edu

David Punzel
dpunzel15@georgefox.edu
*/
function planeChoice (plane) {

// Produce an alert message about the chosen airplane


  switch (plane) {
    case 152:
      alert("Color Green");
      break;
    case 172:
      alert("Color Red");
      break;
    case 182:
      alert("Color Yellow");
      break;
    case 210:
      alert("Color Blue");
      break;
    case 211:
      alert("Color Orange");
      break;
    default:
      alert("Error in JavaScript function planeChoice");
      break;
  }
}

function planeChoice2 (plane2) {

  var dom = document.getElementById("myForm2");

  for (var index = 0; index < dom.pb.length;
       index++) {
    if (dom.pb[index].checked) {
      plane2 = dom.pb[index].value;
      break;
  }
}

// Produce an alert message about the chosen airplane

  switch (plane2) {
    case "152":
      alert("Color Green");
      break;
    case "172":
      alert("Color Red");
      break;
    case "182":
      alert("Color Yellow");
      break;
    case "210":
      alert("Color Blue");
      break;
    case "211":
      alert("Color Orange");
      break;
    default:
      alert("Error in JavaScript function planeChoice");
      break;
  }
}
