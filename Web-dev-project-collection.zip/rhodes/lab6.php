<?php

?>

<form action="/permute.php" method="POST">
  <input type="text" name="word" maxlength="8" required>
  <input type="submit">
</form>
