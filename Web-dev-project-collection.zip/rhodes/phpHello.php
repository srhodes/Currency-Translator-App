<?php

  $numOfOranges = 4;
  $numbOfBananas = 36;

  if(($numOfOranges > 25) && ($numbOfBananas > 30)){
      echo '25% Discount';
  }
  else{
    echo '50% Discount';
  }


?>
